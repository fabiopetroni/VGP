This patch allows to use the HDRF graph partitioning technique in the GraphLab PowerGraph 2.2 software (https://github.com/dato-code/PowerGraph).

HDRF is currently the best performing graph partitioning algorithm, and it is particularly suitable for distributed graph-computing (DGC) frameworks (such as GraphLab).

All you need to do to use the patch is merge the src folder with the one in the GraphLab PowerGraph 2.2 master directory. This process will replace the files src/graphlab/graph/distributed_graph.hpp src/graphlab/graph/ingress/ingress_edge_decision.hpp; moreover it will add the file src/graphlab/graph/ingress/distributed_hdrf_ingress.hpp.

To use HDRF for the ingress partitioning, you need to add the following option:

--graph_opts ingress=hdrf

Notice that you can use the HDRF algorithm when running whichever application, and this choice will considerably reduce the execution time.

The HDRF algorithm is extensively described in the following publication:

F. Petroni, L. Querzoni, K. Daudjee, S. Kamali and G. Iacoboni: 
"HDRF: Stream-Based Partitioning for Power-Law Graphs". 
CIKM, 2015.

If you use the application please cite the paper.

Moreover, you can find it implemented in the VGP tool (https://github.com/fabiopetroni/VGP), a software package for one-pass vertex-cut balanced Graph Partitioning.

Fabio Petroni
www.fabiopetroni.com