This patch allows to use the HDRF graph partitioning technique in the GraphLab PowerGraph 2.2 software (https://github.com/dato-code/PowerGraph).

HDRF is currently the best performing graph partitioning algorithm, and it is particularly suitable for distributed graph-computing (DGC) frameworks (such as GraphLab).

The HDRF algorithm is extensively described in the following publication:

F. Petroni, L. Querzoni, K. Daudjee, S. Kamali and G. Iacoboni: 
"HDRF: Stream-Based Partitioning for Power-Law Graphs". 
CIKM, 2015.

If you use the application please cite the paper.


You can apply this patch by using one of the following two methods:

****************************************************************************
METHOD 1. GIT PATCH (recommended)

All you need to do to apply the patch is run the following commands from terminal:

#1. clone PowerGraph locally
git clone https://github.com/dato-code/PowerGraph.git

#2. enter PowerGraph directory
cd PowerGraph

#3. move patch file in the PowerGraph directory
mv [path to hdrf_powergraph_git.patch] .

#4. apply the patch
git apply --stat hdrf_powergraph_git.patch
****************************************************************************

****************************************************************************
METHOD 2. phisically sobstitute src files

All you need to do to use the patch is merge the src folder with the one in the GraphLab PowerGraph 2.2 master directory. This process will replace the files src/graphlab/graph/distributed_graph.hpp src/graphlab/graph/ingress/ingress_edge_decision.hpp; moreover it will add the file src/graphlab/graph/ingress/distributed_hdrf_ingress.hpp.
****************************************************************************


To use HDRF for the ingress partitioning inside PowerGraph, you need to add the following option:

--graph_opts ingress=hdrf

Notice that you can use the HDRF algorithm when running whichever application, and this choice will considerably reduce the execution time.


Moreover, you can find it implemented in the VGP tool (https://github.com/fabiopetroni/VGP), a software package for one-pass vertex-cut balanced Graph Partitioning.

Fabio Petroni
www.fabiopetroni.com